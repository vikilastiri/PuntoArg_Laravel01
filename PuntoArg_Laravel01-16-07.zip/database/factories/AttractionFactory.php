<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Attraction;
use Faker\Generator as Faker;

$factory->define(Attraction::class, function (Faker $faker) {
    return [
        //
    ];
});
