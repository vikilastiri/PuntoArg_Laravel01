<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\TypeUser;
use Faker\Generator as Faker;

$factory->define(TypeUser::class, function (Faker $faker) {
    return [
        //
    ];
});
