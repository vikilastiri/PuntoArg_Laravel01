<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Voucher;
use Faker\Generator as Faker;

$factory->define(Voucher::class, function (Faker $faker) {
    return [
        //
    ];
});
