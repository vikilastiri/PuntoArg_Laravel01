<?php $__env->startSection('content'); ?>

  




  <div class="fondo">

  </div>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card">
          <div class="card-header"><?php echo e(__('AGREGAR ATRACCION')); ?>

          </div>

          <div class="card-body registro2">
            <form class="" action="/addAttractions" method="POST" enctype="multipart/form-data">

              <?php echo csrf_field(); ?>
              <div class="form-group form-row align-items-center">

                <div class="col-md-6">
                    <label for="name">Nombre</label>
                    <input type="text" id="nameVoucher" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>">  <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                    <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                    </span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
              </div>
              <div class="form-group form-row align-items-center">
                <div class="col-md-12">
                  <label for="description">Descripción</label>
                  <textarea class=" form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  id="description" name="description" value="" autofocus>

                  </textarea>
                  <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                    <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                    </span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

              </div>
              <div class="form-group form-row align-items-center">
                <div class="col-md-12">
                  <input class="form-control <?php if ($errors->has('featured_img')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('featured_img'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"type="file" id="featured_img" class="form-control" name="featured_img" value="" required  autofocus>
                    <?php if ($errors->has('featured_img')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('featured_img'); ?>
                      <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                      </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>
                </div>

                <div class="form-group form-row align-items-center">
                  <label for="">Categorias</label>
                  <select class="form-control " name="category_id">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                                 
                <div class="form-group form-row align-items-center">
                  <label for="locations">Provincia</label>
                  <select id="location_id" class="form-control" name="location_id">

                  </select>
                </div>

                <div class="form-group row  ">
                  <div class="col-md-6">
                    <button class="btn btn-primary" type="submit">Guardar</button>

                  </div>
                </div>
              </form>

            </div>
          </div>
        </div>
      </div>
    </div>

  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('footer', ''); ?>

<?php $__env->startPush('scripts'); ?>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.9.1/underscore-min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PuntoArg_Laravel01\resources\views/addAttractions.blade.php ENDPATH**/ ?>