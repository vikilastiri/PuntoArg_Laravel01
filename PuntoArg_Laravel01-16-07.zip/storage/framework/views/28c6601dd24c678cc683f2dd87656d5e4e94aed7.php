<?php $__env->startSection('content'); ?>
  <div class="fondo">

  </div>
  <div class="container">
      <div class="row justify-content-center">
          <div class="col-md-8">
              <div class="card">
                  <div class="card-header"><?php echo e(__('MI CARRITO')); ?></div>

                  <div class="card-body registro2 ">
                      <ul >

                          <?php $__empty_1 = true; $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          <img src="/storage/vouchers/<?php echo e($items->featured_img); ?>" alt="">
                          <li class="carrito-lista">
                              <h5><?php echo e($items->name); ?></h5>

                              Precio: $ <?php echo e($items->price); ?>

                          </li>
                          <li>
                          <form class="carrito-ul" action="/cart/<?php echo e($items->id); ?>" method="post">
                              <?php echo csrf_field(); ?>
                              <button class="btn btn-secondary" type="submit"><i class="fas fa-trash-alt"></i></button>
                          </form>
                          </li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                          <p>Su carrito está vacío</p>
                          <?php endif; ?>


                          <?php if($cart->isNotEmpty()): ?>
                              <div class="total">
                            <h5>Total: $ <?php echo e($total); ?></h5>
                                </div>
                          <?php endif; ?>


                          <?php if($cart->isNotEmpty()): ?>
                          <a class="btn btn-primary" href="/cart/close">Comprar</a>
                          <?php endif; ?>
                          </ul>


                  </div>
              </div>
          </div>
      </div>
  </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer', ''); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PuntoArg_Laravel01\resources\views/cart.blade.php ENDPATH**/ ?>