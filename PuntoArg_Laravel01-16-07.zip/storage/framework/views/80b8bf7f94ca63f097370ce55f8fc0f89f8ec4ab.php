<?php $__env->startSection('content'); ?>
  <div class="fondo">

</div>
<div class="container">


    <h1>Voucher</h1>
    <div class="row justify-content-center">



                <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-md-8">
              <div class="card text-center">
                <img style="height:400px;" src="/storage/vouchers/<?php echo e($voucher->featured_img); ?>" alt="">
                <h3><?php echo e($voucher->name); ?></h3>
                <p><?php echo e($voucher->description); ?></p>
                <a href="/vouchers/<?php echo e($voucher->id); ?>/addtocart"class="btn btn-primary">Comprar</a>
              </div>
              </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PuntoArg_Laravel01\resources\views/vouchers.blade.php ENDPATH**/ ?>