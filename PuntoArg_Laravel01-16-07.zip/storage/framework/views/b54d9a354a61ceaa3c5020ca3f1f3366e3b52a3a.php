<?php $__env->startSection('content'); ?>

<section class="carousel">
  <div class="titulo">
    <p>PuntoARG es tu tarjeta de descuentos para turismo en la Argentina.</p>
  </div>
    <div class="">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="\storage\attractions\4Q8Kx3U0H9Xlj7qOrHonZynhpJF1OsEcW5is5t1i.jpeg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="\storage\attractions\89euzarOCD8zCf22aTlhjqUKpfWLIS8NSd9Usr8A.jpeg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="\storage\attractions\qn2gzfDEXnwFBV7GebBAoVq6JjJStQqzFYMwdYol.jpeg" class="d-block w-100" alt="...">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Anterior</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Siguiente</span>
            </a>
        </div>
    </div>

<div class="container flex-container2">
    <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<article class="destacado card text-center">

  <a href="#" class="desta-link desta"><img src="/storage/vouchers/<?php echo e($voucher->featured_img); ?>" alt=""> </a>
    <h4 class="att_name"><?php echo e($voucher->name); ?> - AR$ <?php echo e($voucher->price); ?></h4>
    <p class="txt-desc"><?php echo e($voucher->description); ?></p>
    <ul class="">
      <li class=""><a href="/vouchers/<?php echo e($voucher->id); ?>/addtocart" class="btn btn-primary">Comprar</a></li>
    </ul>

      </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

</section>
<!--ATRACCIONES DESTACADAS-->


<section class="titulo-seccion">
    <span class="">
        <h4 class="titulo-desta">Nuestras Atracciones Bonificadas:</h4>
    </span>

</section>

<section class="destacados">

<div class="flex-container2  container  ">
    <?php $__empty_1 = true; $__currentLoopData = $attractions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attraction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<article class="destacado ">

  
    <img src="/storage/attractions/<?php echo e($attraction->featured_img); ?>" alt="">
  
    <h5 class="att_name"><?php echo e($attraction->name); ?></h5>
    
    <ul class="consulta-desta">
      <li class="consulta"><a href="#"  data-name="<?php echo e($attraction->name); ?>" data-description="<?php echo e($attraction->description); ?>">+ Info</a></li>
    </ul>

      </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <?php endif; ?>
  </div>
  <div class="flex-container">
    <span class="btn btn-primary ver-mas"> <a href="/attractions">Ver más</a> </span>
  </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PuntoArg_Laravel01\resources\views/home.blade.php ENDPATH**/ ?>