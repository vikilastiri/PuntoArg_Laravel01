

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php echo e(config('views.name', 'PuntoARG - Tarjeta de descuentos para turismo en la Argentina')); ?></title>

  <!-- Scripts -->

  <!-- Fonts -->
  <link rel="dns-prefetch" href="//fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Lato|Roboto+Condensed" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">

  <link href="https://fonts.googleapis.com/css?family=Baloo+Chettan" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

  <!-- Styles -->
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/puntoarg.css')); ?>" rel="stylesheet">




</head>
<body>
  <div id="app">
    <nav class="navbar navbar-expand-md navbar-light bg-blue shadow-sm">
      <div class="container">
        <a class="marcalogo" href="<?php echo e(url('/')); ?>">
          PuntoARG
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
          <span class="navbar-toggler-icon "></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">

          <!-- Left Side Of Navbar -->
          <ul class="navbar-nav mr-auto">

          </ul>

          <!-- Right Side Of Navbar -->

          <ul class="navbar-nav ml-auto ">

            <li class="nav-item dropdown">
              <a class="linkmenu "href="/attractions">Atracciones</a>
            </li>

            <li class="nav-item dropdown">
              <a class="linkmenu dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Tarjetas
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <span class="dropdown-header">.ArgPass</span>
                <span class=""></span>
                <a class="dropdown-item" href="/vouchers">Tarjeta 3 Días</a>
                <a class="dropdown-item" href="/vouchers">Tarjeta 7 Días</a>
                <a class="dropdown-item" href="/vouchers">Tarjeta 15 Días</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="/faq">Formas de pago</a>
                <a class="dropdown-item" href="/faq">FAQ</a>
              </div>
            </li>
            
          <!-- Authentication Links -->
          <?php if(auth()->guard()->guest()): ?>
            <?php if(Route::has('register')): ?>
              <li class="nav-item">
                <a class="linkmenu" href="<?php echo e(route('login')); ?>"><?php echo e(__('Registro/Login')); ?> </a>
              </li>
            <?php endif; ?>
          <?php else: ?>
            <li class="nav-item dropdown">
              <a style="font-weight:700" id="navbarDropdown" class="linkmenu dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
              </a>

              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item"href="/cart">Carrito</a>

                <?php if(Auth::user()->type_users == 1): ?>
                  <a class="dropdown-item"href="/addAttractions">Añadir Atracción</a>
                  <a class="dropdown-item"href="/addVoucher">Añadir Tarjeta</a>
                <?php endif; ?>

                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

              </a>

              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
              </form>

            </div>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<main class="py-4">
  <?php echo $__env->yieldContent('content'); ?>
</main>
<?php $__env->startSection('footer'); ?>
  <footer class="footer ">
    <div class="container secciones ">


      <section class="mas-info " >
        <h2>Más Info:</h2>
        <ul>
          <div class="infocard">
            <div class="info">

              <li><a href="/faq"><i class="far fa-credit-card"></i><br>Formas de Pago</a>
              </li>

            </div>

            <div class="info">


              <li><a href="/faq"><i class="fas fa-store"></i><br>PostVenta</a></li>
            </div>
          </div>
        </ul>
      </section>

      <section class="oficinas">
        <h2>Nuestras Oficinas</h2>
        <p> Av. Monroe 860<br>
          CABA, Buenos Aires<br></p>

          <p>
            <i class="fas fa-mobile-alt"></i>11-5263-7400 </p>

          </section>

          <section class="social">
            <h2>¡Seguinos!</h2>
            <ul>
              <li><a href="https://www.instagram.com/visitargentina/"><i class="fab fa-twitter"></i></a></li>
              <li><a href="https://www.instagram.com/visitargentina/"><i class="fab fa-instagram"></i></a></li>
              <li><a href="https://www.instagram.com/visitargentina/"><i class="fab fa-facebook"></i></a></li>
              <li><a href="https://www.instagram.com/visitargentina/"><i class="fab fa-youtube"></i></a></li>
            </ul>
          </section>
        </div>
      </footer>
    <?php echo $__env->yieldSection(); ?>
  </div>


  <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <script src="<?php echo e(asset('js/extra.js')); ?>" defer></script>

  <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\PuntoArg_Laravel01\resources\views/layouts/app.blade.php ENDPATH**/ ?>