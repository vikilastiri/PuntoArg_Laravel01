<?php $__env->startSection('content'); ?>
  <div class="fondo">

</div>
<div class="container">
          <section class="faq">
            <div class="preguntas">
              <h3 class="card-header">Preguntas frecuentes</h3><br>
              <ul>
                <li>¿Cuándo se activa mi abono Argentina Pass?</li>
                <li>  ¿Hay un límite en el número de atracciones que puedo ver en un día?</li>
                <li>¿Puedo visitar la misma atracción más de una vez?</li>
                <li>¿tienen que usarse en días consecutivos?</li>
                <li>  ¿Y si pierdo mi abono Argentina Pass?</li>
                <li>El Argentina Pass, ¿ofrece descuentos a los usuarios del Metro?</li>
                <li>Tengo un vale electrónico. ¿Dónde puedo recoger mi Pass?</li>
                  <li>¿Tengo que recoger los Pass el mismo día en que los compro en línea?</li>
                  <li>  La recogida del Pass en la sede de rescate, ¿activará mi tarjeta?</li>
                  <li>¿Pueden enviarme mi Pass y mi Guía?</li>

              </ul>


            </div>

          </section>


</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer', ''); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PuntoArg_Laravel01\resources\views/faq.blade.php ENDPATH**/ ?>