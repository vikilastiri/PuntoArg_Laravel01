<?php $__env->startSection('content'); ?>
  <div class="fondo">

</div>
<div class="container">
  <div class="row justify-content-center">
      <div class="col-md-8">
    <div class="card">
        <div class="card-header"><?php echo e(__('AGREGAR VOUCHER')); ?>

        </div>

        <div class="card-body registro2">
            <form class="" action="/addVoucher" method="POST" enctype="multipart/form-data">

                <?php echo csrf_field(); ?>
                <div class="form-group form-row align-items-center">

                    <div class="col-md-6">
                        <label for="name">Nombre</label>
                        <input type="text" id="nameVoucher" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>"> <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($message); ?></strong>
                              </span>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="form-group form-row align-items-center">
                    <div class="col-md-12">
                        <label for="description">Descripción</label>
                        <textarea class=" form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="description" name="description" value="">

              </textarea>
              <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="form-group form-row align-items-center">
                  <div class="col-md-12">  <label for="description">Precio</label>
                    <input id="price" class="form-control <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"type="number" name="price" value=""><?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>
                </div>
                <div class="form-group form-row align-items-center">
                    <div class="col-md-12">
                        <label for="featured_img">Imagen</label>
                        <input type="file" id="featured_img" class="form-control  <?php if ($errors->has('featured_img')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('featured_img'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> " name="featured_img" value="" required  autofocus>  <?php if ($errors->has('featured_img')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('featured_img'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>


                <div class="form-group row  ">
                    <div class="col-md-6">
                        <button class="btn btn-primary" type="submit">Guardar</button>

                    </div>
                </div>
            </form>

        </div>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer', ''); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PuntoArg_Laravel01\resources\views/addVoucher.blade.php ENDPATH**/ ?>