<?php $__env->startSection('content'); ?>







      <!--DESTACADOS-->
      <section class="destacados">

        <div class="">
          <span class=" flex-container">
              

            <form class="buscador" action="/attractions/buscar" method="get" >
              <?php echo csrf_field(); ?>

              <input class=""type="text" name="search" value="" >
              <button
              class=" btn btn-primary" type="submit"><i class="fas fa-search"></i></button>

            </form>
            <form class="buscador" action="/attractions" method="get">
              <?php echo csrf_field(); ?>
              <button  class=" btn redo-search btn-secondary" type="submit"><i class="fas fa-redo"></i></button>
            </form>


          </span>

    </div>



          <div class="container flex-container2">
              <?php $__currentLoopData = $attractions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attraction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <article class="destacado">

            
              <img src="/storage/attractions/<?php echo e($attraction->featured_img); ?>" alt="">
            
              <h5 class="att_name"><?php echo e($attraction->name); ?></h5>
              
              <ul class="consulta-desta">
                <li class="consulta"><a href="#" data-name="<?php echo e($attraction->name); ?>" data-description="<?php echo e($attraction->description); ?>">+ Info</a></li>
              </ul>

                </article>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="flex-container paginacion">
              <?php if(isset($_GET['search'])): ?>
              <?php echo e($attractions->links()); ?>

              <?php endif; ?>
            </div>



</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PuntoArg_Laravel01\resources\views/attractions.blade.php ENDPATH**/ ?>